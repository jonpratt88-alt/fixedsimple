
# KidsBook MVP — Fixed

**What changed vs the first zip**
- `index.html` is now at the repo **root** (Vercel serves it by default).
- API routes explicitly parse JSON request bodies (so POST /api/story & /api/image work reliably).
- Added `vercel.json` to route `/` → `/index.html` and `/api/*` → serverless functions.

## Deploy (fresh)
1) Create a new Vercel project from this folder (or replace the files in your current one).
2) Add env var: `OPENAI_API_KEY`.
3) Deploy → visit your URL → it should load instead of 404.

## Local (optional)
- Node 18+, then:
  ```
  npm install
  npx vercel dev
  ```
