// api/story.js — Vercel Serverless Function (Node.js)
const OpenAI = require("openai");

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => data += chunk);
    req.on("end", () => {
      try { resolve(JSON.parse(data || "{}")); }
      catch (e) { resolve({}); }
    });
    req.on("error", reject);
  });
}


module.exports = async (req, res) => {
  try {
    if (req.method !== "POST") {
      res.statusCode = 405;
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify({ error: "Method not allowed" }));
      return;
    }
    const body = await readBody(req);
    const { child = "Poppie", age = 3, theme = "friendship", faithTone = "gentle", style = "cozy cartoon" } = body;

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const system = "You are a children's author who ONLY returns valid JSON.";
    const user = `
Write a calm bedtime story for a ${age}-year-old named ${child}.
Theme: ${theme}. Faith tone: ${faithTone} (none|gentle|explicit).
Rules:
- 6–8 pages. Each page: 1–2 short sentences, simple vocabulary, present tense.
- No scary content; warm, reassuring tone; end softly.
Return strictly as compact JSON:
{
  "title": "...",
  "pages": [
    {
      "text": "Page text here.",
      "art_prompt": "Single illustration description: include character(s) looks, scene, style: ${style}, lighting: warm bedtime, keep consistency."
    }
  ]
}`.trim();

    const chat = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.8,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ]
    });

    const content = chat.choices?.[0]?.message?.content || "{}";
    let story;
    try {
      story = JSON.parse(content);
    } catch (e) {
      const start = content.indexOf("{");
      const end = content.lastIndexOf("}");
      if (start >= 0 && end > start) {
        story = JSON.parse(content.slice(start, end + 1));
      } else {
        throw e;
      }
    }

    res.setHeader("content-type", "application/json");
    res.statusCode = 200;
    res.end(JSON.stringify(story));
  } catch (err) {
    console.error(err);
    res.statusCode = 500;
    res.setHeader("content-type", "application/json");
    res.end(JSON.stringify({ error: "Story generation failed", details: String(err) }));
  }
};
