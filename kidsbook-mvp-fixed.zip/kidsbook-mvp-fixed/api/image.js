// api/image.js — Vercel Serverless Function (Node.js)
const OpenAI = require("openai");

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => data += chunk);
    req.on("end", () => {
      try { resolve(JSON.parse(data || "{}")); }
      catch (e) { resolve({}); }
    });
    req.on("error", reject);
  });
}


module.exports = async (req, res) => {
  try {
    if (req.method !== "POST") {
      res.statusCode = 405;
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify({ error: "Method not allowed" }));
      return;
    }
    const body = await readBody(req);
    const { art_prompt = "Cute cozy bedtime illustration", seed = "" } = body;

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const result = await openai.images.generate({
      model: "gpt-image-1",
      prompt: `${art_prompt}\nKeep character consistency. ${seed ? 'Seed:' + seed : ''}`.trim(),
      size: "1024x1024"
    });

    const b64 = result.data?.[0]?.b64_json;
    if (!b64) {
      res.statusCode = 500;
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify({ error: "No image returned" }));
      return;
    }

    res.setHeader("content-type", "application/json");
    res.statusCode = 200;
    res.end(JSON.stringify({ b64 }));
  } catch (err) {
    console.error(err);
    res.statusCode = 500;
    res.setHeader("content-type", "application/json");
    res.end(JSON.stringify({ error: "Image generation failed", details: String(err) }));
  }
};
